# initial version automatically generated from ./release-process/scripts/mk_exim_release
EXIM_RELEASE_VERSION=4.89
EXIM_VARIANT_VERSION=
EXIM_COMPILE_NUMBER=0
